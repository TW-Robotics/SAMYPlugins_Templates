# SAMYPlugin package

## Install
To use subscriptions you have to install the modified version of the python opcua package.
`pip3 install opcua/.`
